import SwiftUI

@main
struct BallGameApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

