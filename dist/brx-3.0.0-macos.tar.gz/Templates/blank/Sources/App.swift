import SwiftUI

@main
struct BlankApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

